<?php
$host = "localhost";
$usuario= "root";
$senha = "";
$db=mysql_connect($host,$usuario,$senha) or die ("Não foi possível conectar com o servidor de banco de dados");
mysql_select_db("lojavirtual_2e",$db) or die ("Não foi possívelconectar com o banco de dados");
 ?>
