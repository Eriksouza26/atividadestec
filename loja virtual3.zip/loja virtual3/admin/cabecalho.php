<!DOCTYPE html>
<html lang="pt-br">
<head><title></title><meta charset="utf-8"></head>
<BODY>
<table width=100% border=0 cellspacing=0 cellpadding=0>
<tr><td><table width=100% border=0 cellspacing=0 cellpadding=0><tr>
<td width=20%><img src=imagens/logo.jpg width=210 height=117></td>
<td width=61%><table width=100% border=0 cellspacing=0 cellpadding=0>
<tr><td>www.lojavirtual.com.br</td><td rowspan=2> &nbsp;</td></tr>
<tr><td colspan="2"><table width=100% border=0 cellspacing=0 cellpadding=0><tr>
<td>Data: <?php
$dia_da_semana=array("Domingo","Segunda", "Terça","Quarta", "Quinta", "Sexta",
"Sábado");
$num_dia=date("w"); $dia_extenso=$dia_da_semana[$num_dia];
echo $dia_extenso." ,".date("d/m/Y");
?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp; Hora:<?php
date_default_timezone_set('America/Sao_Paulo'); $date = date('H:i'); echo $date;
?><td><td>IP:
<?php
$ip = getenv("REMOTE_ADDR"); echo $ip; ?></td></tr> <tr>
<td colspan=3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>
<tr><td colspan=3><div align=Right> Desenvolvedor: Erik Magalhães de Souza</div></td></tr>
</table></td></tr></table></td><td width=5%><img
src=imagens/adm.jpg></td></tr>
</table></td></tr><tr><td><img src=imagens/administra.jpg
width=100%></td></tr>
</table>
</BODY>
</HTML>