<HTML>
<HEAD>
<TITLE> DOCUMENTO PHP </TITLE>
</HEAD>
<BODY>
<?php
include "Conexao.php";
echo"<form action='alterar2.php' method='POST'>";
echo "Digite o codigo de cliente para alterar os dados.<br>
<input name='codigo' type='text' size=4><br>";
echo"<a href='alterar2.php'><input type='submit' value='Clique aqui para confirmar a alteracao.'><a>";
echo"</form>";
?>
</BODY>
</HTML>