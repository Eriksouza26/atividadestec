<?php 
$host="localhost";
$usuario="root";
$senha="";
$banco="PPDP";

$link=mysql_connect($host,$usuario,$senha) or die ("Não foi possível conectar:".mysql_error());

$conexaobd=mysql_select_db($banco, $link) or die ("Erro ao abrir o banco".mysql_error());

$busca=mysql_query("select * from USERS ") or die ("Erro ao abrir o busca:".mysql_error());
?>