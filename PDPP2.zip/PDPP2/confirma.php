<HTML>
<HEAD>
<TITLE> DOCUMENTO PHP </TITLE>
<?php 
include "Conexao.php";
?>
</HEAD>
<BODY>
<?php
$codigo=$_POST['codigo'];
$sql="delete from USERS where id='$codigo'";
$resultado=mysql_query($sql) or die ("Não foi possivel realizar a consulta ao banco de dados.");
echo "<br>Usuario excluido com sucesso!!!";
echo "<br><br> <a href='vizualizar.php'>Veja se o usuario foi excluido</a> <br>";
?>
</BODY>
</HTML>