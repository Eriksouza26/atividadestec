<HTML>
<HEAD>
<TITLE> DOCUMENTO PHP </TITLE>
</HEAD>
<BODY>
<?php
include "Conexao.php";
$codigo=$_POST['codigo_novo'];
$nome=$_POST['nome_novo'];

$sql="Update USERS set id='$codigo', nome='$nome' where id='$codigo'";
$resultado=mysql_query($sql) or die ("Nao foi possivel a conexao com o banco de dados.");
echo "<h1>dados do usuario foram alterados com sucesso!</h1>";
echo "<br><br> <a href='index.php'><input type=button name=voltar value='Cadastrar novo usuario'></a> <br>";
echo "<br><br> <a href='vizualizar.php'><input type=button name=vizu value='Vizualizar usuarios'></a> <br>";
?>
</BODY>
</HTML>