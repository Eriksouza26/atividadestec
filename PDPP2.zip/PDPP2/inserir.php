<HTML>
<HEAD>
<TITLE> DOCUMENTO PHP </TITLE>
</HEAD>
<BODY>
<?php
$data=date("Y-m-d");
$hora=date("H:i:s");

include "Conexao.php";

$nome=$_POST['nome'];

$sql="insert into USERS(nome,hora,data)  values ('$nome','$hora','$data')";
echo "<h1> Cadastro efetuado com sucesso!<h1>";
$sql=mysql_query($sql) or die ("Houve erro na geração dos dados!" .mysql_error());

echo "<a href='vizualizar.php'>Clique aqui para ir para a lista de usuarios</a>"

?>

</BODY>
</HTML>