<HTML>
<HEAD>
<TITLE> VIZUALIZAR </TITLE>
</HEAD>
<BODY>
<?php 
include "Conexao.php";
echo "<h1>Lista dos usuarios</h1>";


while ($reg=mysql_fetch_assoc($busca))
{
	echo "<hr>";
	echo"<br>Codigo:".$reg["id"];
    echo"<br>Nome:".$reg["nome"];
    echo"<br>Data:".$reg["data"];
    echo"<br>Hora:".$reg["hora"];
}
echo "<hr>";
mysql_free_result($busca);
mysql_close($link);


?>
<a href='alterar.php'><input type=button name=alterar value=alterar></a>
<a href='excluir.php'><input type=button name=excluir value=excluir></a>
</BODY>
</HTML>