<HTML>
<HEAD>
<TITLE> DOCUMENTO PHP </TITLE>
<?php
include "Conexao.php";
?>
</HEAD>
<BODY>
<?php
echo "<form action='confirma.php' method=POST>";
echo "Digite o codigo para confirmar a exclusao do cliente<br>
<input name='codigo' type='text' size=30<br>>";
echo "<input type='submit' value='Confirmar Exclusao'>";
echo"</form>";
?>
</BODY>
</HTML>