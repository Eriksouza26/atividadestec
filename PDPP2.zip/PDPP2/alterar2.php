<HTML>
<HEAD>
<TITLE> DOCUMENTO PHP </TITLE>
</HEAD>
<BODY>
<?php
include "Conexao.php";
$codigo=$_POST['codigo'];
$sql="select * from USERS where id='$codigo'";
$resultado=mysql_query($sql) or die 
("Nao foi possivel realizar a consulta ao banco de dados.");
while ($linha=mysql_fetch_array($resultado)){
	$codigo=$linha['id'];
	$nome=$linha['nome'];
	echo "<h1>Alterar Cadastro...</h1>";
	echo "<hr><br>";
	echo "<form action='alterar_db.php?id=$codigo' method='POST'>";
	echo "Codigo do cliente:<input name='codigo_novo'
	type = 'text' value='$codigo' size=30>*<br>";
	echo "Nome:<input name='nome_novo'
	type = 'text' value='$nome' size=30>*<br>";
	echo "<input type='submit' value='Alterar'>";
	echo"</form>";
	echo"<br><hr>";
}
?>
</BODY>
</HTML>