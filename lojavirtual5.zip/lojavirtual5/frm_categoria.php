﻿<?php
include "conexao.php";
$acao = $_GET['acao'];
$id = $_GET['id'];
if ($acao != "")
{
$sql   = "SELECT * FROM categoria WHERE id_categoria = '$id'";
$qry   = mysql_query($sql);
$linha = mysql_fetch_array($qry);
$categoria = $linha['categoria'];
 }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<title></title>
<meta charset="utf-8">
</head>
<BODY>
 <table border="0" width="100%" cellspacing="0" cellpadding="0">
<tr>
  <td><div align="center">Cadastro de Categorias</div></td>
</tr>
<tr>
  <td>
  <form id="form1" name="form1" method="post" action="op_categoria.php">
   <table border="1" width="314" align="center" cellspacing="0" cellpading="0">
<tr>
  <td>Categoria</td>
  <td>
  <label><input type="text" name="txt_categoria" id="txt_categoria" value="<?php echo $categoria; ?>" size="35">
  </label> </td>
</tr>
<tr>
  <td colspan="2"><div align="center">
  <input type="submit" name="submit" value="<?php if ($acao !="") {
  echo $acao;} else  {  echo "Inserir";} ?>">
  <input name="acao" type="hidden" id="acao" value="<?php if ($acao !="") {
  echo $acao;} else  {    echo "Inserir";} ?>">
  <input name="id" type="hidden" id="id" value="<?php echo $id; ?>">
  </div>
  </td>

</tr>
</table>
  
  </form>

  </td>
</tr>
<tr>
  <td>&nbsp;</td>
</tr>
</table>

</BODY>
</HTML>



