﻿<?php
include "conexao.php";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<title></title>
<meta charset="utf-8">
</head>
<body>
<table width=750 border=0>
<tr>
<td colspan=2><?php include "cabecalho.php"; ?></td>
</tr>
<tr>
<td width=140 valign="top"><?php include "menu.php"; ?></td>
<td width=610> <table width=750 border=0 >
<tr> <td valign="top"><?php
$link=@$_GET['link'];
$pag[1]="home.php";

$pag[2]="lst_categoria.php";
$pag[3]="frm_categoria.php";

$pag[4]="lst_subcategoria.php";
$pag[5]="frm_subcategoria.php";
$pag[6]="Produto/index.php";

if (!empty($link) )  {


if (file_exists($pag[$link])) {
include $pag[$link];
}
else {
include "home.php";
}
}
else{

include "home.php";
}
 ?></td> </tr>
</table>
 </td>
</tr>
<tr>
<td colspan=2><?php include "rodape.php";?></td>
</tr>
</table>
</body>
</HTML>
