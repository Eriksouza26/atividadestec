<?php

$host = "localhost";
$usuario= "root";
$senha = "";
$db=mysql_connect($host,$usuario,$senha) or die ("N�o foi poss�vel conectar com o servidor de banco de dados");
mysql_select_db("lojavirtual",$db) or die ("N�o foi poss�velconectar com o banco de dados");

?>
