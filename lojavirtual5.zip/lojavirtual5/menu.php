﻿<!DOCTYPE html>
<html lang="pt-br">
<head>
<title></title>
<meta charset="utf-8">
</head>
<BODY>
<Table width="200" border=0>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>&nbsp;</td><td><table width="178" border=0 height=100%>
     <tr><td><img src=imagens/menu.jpg width="178" height="31"></td></tr>
     <tr><td>
             <a href="index.php?link=1"> Página Inicial</a><br />
             <a href="index.php?link=2">Categoria</a><br />
             <a href="index.php?link=4">Subcategoria</a><br />
             <a href="index.php?link=6">Carrinho</a><br />
    
     </td></tr>
     </table></td> <td>&nbsp;</td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
</table>
</BODY>
</HTML>
