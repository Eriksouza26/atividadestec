<?php
session_start();
if(!isset($_SESSION['carrinho'])){
    $_SESSION['carrinho']
=array();
}
if(isset($_GET['acao'])){
    $id=intval($_GET['id']);
if(!isset($_SESSION['carrinho'][$id])){
    $_SESSION['carrinho'][$id]=1;
}else{
    $_SESSION['carrinho'][$id]+=1;
}
}
if($_GET['acao']=='del'){
    $id=intval($_GET['id']);
if(isset($_SESSION['carrinho'][$id])){
unset($_SESSION['carrinho'][$id]);
}
}
if($_GET['acao']=='up'){
    if(is_array($_POST['prod'])){
        foreach($_POST['prod']as $id =>$qtd)
        $id=intval($id);
        $qtd=intval($qtd);
        if(!empty($qtd)|| $qtd<>0){
            $_SESSION['carrinho'] [$id]=$qtd;
        }else{
            unset($_SESSION['carrinho']{$id});
        }
    }
}
?>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<meta http-equiv="content-Type" content="text/html;charset=iso-8859-1"/>
<title>NOVO DOCUMENTO</title>
</head>
<body>
<table border=1>
<caption>Carrinho de Compras</caption>
<thead>
<tr>
<th width="244">Produto</th>
<th width="79">Quantidade</th>
<th width="89">Preço</th>
<th width="100">Subtotal</th>
<th width="64">Remover</th>
</tr>
</thead>
<form action="?acao=up" method="post">
<tfoot>
<tr><td colspan="5"><input type="submit" value="Atualizar Carrinho"/></td>
</tr>
<tr><td colspan="5"><a href="index.php">Continuar Comprando</a></td>
</tr>
</tfoot>
<tbody>
<?php
$total=0;
if(count($_SESSION['carrinho'])==0){
    echo '<tr><td colspan="5">Não há produtos no carrinho</td></tr>';
}else{
    require("conexão.php");
    foreach($_SESSION['carrinho']as $id=>$qtd){
        $sql="Select * from produto where id='$id'";
        $qr=mysql_query($sql)or die (mysql_error());
        $ln=mysql_fetch_assoc($qr);
        $nome+$ln['nome'];
        $preco=number_format($ln['preco'],2,',','.');
        $sub=number_format($ln['preco']*$qtd,2,',','.');
        $total+=$sub;
        echo '<tr><td>'.$nome.</td>
        <td><input type="text" size=3 name="prod['.$id.']"value="'.$qtd.'"></td>
        <td>'.$preco.'</td>
        <td>'.$sub.'</td>
        <td><a href="?acao=del&id='.$id.'">Remove</a></td></tr>';
    }
    $total=number_format($total,2,',','.');
    echo'<tr. <td colspan="4"> Total</td><td>R$'.$total.'</td></tr>';
}
</tbody>
</form>
</table>
</body>
</html>