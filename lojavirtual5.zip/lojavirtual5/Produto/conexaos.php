<?php
$host = "localhost";
$usuario= "root";
$senha = "";
$db=mysql_connect($host,$usuario,$senha) or die
("Não foi possível
conectar com o servidor de banco de dados");
mysql_select_db("loja",$db) or die ("Não foi possível
conectar com o banco de dados");
?>