<html>
<head><title></title>
<meta http-equiv="content-type" content="text/html;charset=utf-8"/>
<meta http-equiv="content-Type" content="text/html;charset=iso-8859-1"/>
<?php
require("conexaos.php");
$sql="select * From produto";
$qr=mysql_query($sql) or die (mysql_error());
while ($ln=mysql_fetch_assoc($qr)){
    echo '<h2>'.$ln['nome'].'</h2><br/>';
    echo 'Preço:R$'.number_format($ln['preco'],2,',','.').'<br/>';
    echo '<img src="image/'.$ln['imagem'].'"/><br>';
    echo '<a href="carrinho.php?acao=add&id='.$ln['id'].'">comprar</a>';
    echo '<br/><hr/>';
}
?>
</body>
</html>