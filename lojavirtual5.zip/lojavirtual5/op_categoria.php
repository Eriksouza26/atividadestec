<?php
include "conexao.php";
$acao  = $_POST['acao'];
$id  = $_POST['id'];
$txt_categoria = $_POST['txt_categoria'];
if ($acao== "Inserir")
{
$sql="INSERT INTO categoria (categoria) VALUES ('$txt_categoria')";
mysql_query($sql) or die ("N�o foi poss�vel inserir os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=2'</script>";
 }
 if ($acao== "Alterar")
 {
 $sql="UPDATE categoria SET categoria = '$txt_categoria' WHERE id_categoria = '$id'";
mysql_query($sql) or die ("N�o foi poss�vel alterar os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=2'</script>";
  }
  if ($acao== "Excluir")
 {
 $sql="DELETE FROM categoria WHERE id_categoria = '$id'";
mysql_query($sql) or die ("N�o foi poss�vel Excluir os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=2'</script>";
  }

?>
