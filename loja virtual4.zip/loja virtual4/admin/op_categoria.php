<?php
include "conexao.php";
$acao  = $_POST['acao'];
$id  = $_POST['id'];
$txt_categoria = $_POST['txt_categoria'];
if ($acao== "Inserir")
{
$sql="INSERT INTO categoria (categoria) VALUES ('$txt_categoria')";
mysql_query($sql) or die ("Não foi possível inserir os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=2'</script>";
 }
 if ($acao== "Alterar")
 {
 $sql="UPDATE categoria SET categoria = '$txt_categoria' WHERE id_categoria = '$id'";
mysql_query($sql) or die ("Não foi possível alterar os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=2'</script>";
  }
  if ($acao== "Excluir")
 {
 $sql="DELETE FROM categoria WHERE id_categoria = '$id'";
mysql_query($sql) or die ("Não foi possível Excluir os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=2'</script>";
  }
?>
