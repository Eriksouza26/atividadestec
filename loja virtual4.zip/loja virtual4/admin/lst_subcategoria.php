<!DOCTYPE html>
<html lang="pt-br">
<head>
<?php
include "conexao.php";
?>
<title></title>
<meta charset="utf-8">
</head>
<BODY> <table border="0" width="100%" cellspacing="0" cellpadding="0">
<tr>
  <td><div align="center"><strong>Lista de Subcategorias</strong></div></td>
</tr>
<tr>
  <td><table border="1" width="100%" cellspacing="0" cellpadding="0">
<tr>
 <td width="8%"><b>Código</b></td>
  <td width="79%"><b>Subcategorias</b></td>
  <td colspan="2"><b>Ação</b></td> </tr>
<?php
$sql = "SELECT * FROM subcategoria";
$qry = mysql_query($sql);
while($linha = mysql_fetch_array($qry)){
?>
<tr>
  <td><?php echo $linha['id_subcategoria']; ?></td>
  <td><?php echo $linha['subcategoria']; ?></td>
  <td width="5%"><a href="index.php?link=5&acao=Alterar&id=<?php echo $linha['id_subcategoria'];?>">
<img src="imagens/alterar.jpg" width="25" heigh="25"></a></td>
  <td width="15%"><a href="index.php?link=5&acao=Excluir&id=<?php echo $linha['id_subcategoria'];?>">
<img src="imagens/excluir.jpg" width="30" heigh="30"></a></td>
</tr> <?php } ?> <tr>  <td>&nbsp;</td>
  <td colspan="2"><div align="right"><a href="index.php?link=5&acao=Inserir&id=<?php echo $linha['id_subcategoria'];?>"><img src="imagens/inserir.jpg" width="50" heigh="50"></a></div></td>
 </tr></table>&nbsp;</td>
</tr><tr> <td>&nbsp;</td></tr></table>
</BODY>
</HTML>
