<?php
include "conexao.php";
$acao  = $_POST['acao'];
$id  = $_POST['id'];
$txt_subcategoria = $_POST['txt_subcategoria'];
$id_categoria = $_POST['id_categoria'];
 if($acao== "Inserir"){
$sql="INSERT INTO subcategoria (id_categoria,subcategoria)
VALUES ('$id_categoria','$txt_subcategoria')";
mysql_query($sql) or die ("Não foi possível inserir os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=4'</script>";
 }
if ($acao== "Alterar")
 {
 $sql="UPDATE subcategoria SET id_categoria = '$id_categoria',
 subcategoria='$txt_subcategoria' WHERE id_subcategoria = '$id'";
mysql_query($sql) or die ("Não foi possível alterar os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=4'</script>";
  } 
  if ($acao== "Excluir")
 {
 $sql="DELETE FROM subcategoria WHERE id_subcategoria = '$id'";
mysql_query($sql) or die ("Não foi possível Excluir os dados");
echo "<script type='text/javascript'>location.href ='index.php?link=4'</script>";
  }
?>
