<?php
include "conexao.php";
$acao = $_GET['acao'];
$id = $_GET['id'];
if ($acao != "")
{
$sql   = "SELECT c.*,s.* FROM categoria c,subcategoria s WHERE
c.id_categoria=s.id_categoria and id_subcategoria ='$id'";
$qry   = mysql_query($sql);
$linha = mysql_fetch_array($qry);
$subcategoria = $linha['subcategoria'];
$id_categoria = $linha['id_categoria'];
 }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<title></title><meta charset="utf-8"></head>
<BODY>
 <table border="0" width="100%" cellspacing="0" cellpadding="0">
<tr>
  <td><div align="center">Cadastro de Subcategorias</div></td>
</tr> 
<tr>
  <td>
  <form id="form1" name="form1" method="post" action="op_subcategoria.php">
   <table border="1" width="314" align="center" cellspacing="0" cellpading="0">
<tr>
<td>Categoria</td>
  <td><label>
    <select name="id_categoria" id="id_categoria"> 
    <option>Selecione uma categoria</option>
    <?php
    $sql="SELECT * FROM categoria ORDER BY categoria";
    $qry= mysql_query($sql);
    while ($linha=mysql_fetch_array($qry)){
    $valor = $linha['id_categoria'];
    if ($id_categoria = $valor)
    {
    $selecionado = "selected";
    }  else  {
    $selecionado ="";
    }
 echo "<option value= \"$valor\" $selecionado > $linha[categoria]</option>";
    }   ?>
</select>
  </label></td></tr> 
  <tr>
  <td>Subcategoria</td>
 <td><input type="text" name="txt_subcategoria" id="txt_subcategoria"
 value="<?php echo $subcategoria; ?>" size="35"></td>
  </tr> <tr>
  <td colspan="2"><div align="center">
  <input type="submit" name="submit" value="<?php if ($acao !="") {
  echo $acao;} else  {  echo "Inserir";} ?>">
  <input name="acao" type="hidden" id="acao" value="<?php if ($acao !="") {
  echo $acao;} else  {    echo "Inserir";} ?>">
  <input name="id" type="hidden" id="id" value="<?php echo $id; ?>">
</div> </td></tr></table></form></td></tr><tr><td>&nbsp;</td></tr></table>
</BODY></HTML>
