<!DOCTYPE html>
<html lang="pt-br">
<head>
<title></title>
<meta charset="utf-8">
</head>
<BODY>
<img src=imagens/rodape.jpg>
</BODY>
</HTML>