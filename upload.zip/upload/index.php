<html>
<title></title>
<head>
<body>
    <form enctype="multipart/form-data" action="upload.php" method="POST">
    <input type="file" name="arquivo" >
    <input type="submit" value="enviar">
    </form>
    



</body>

</head>
</html>


