<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "sessoes";
	

	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
