<HTML>
<HEAD>
<TITLE> Cadastrar </TITLE>
</HEAD>
<BODY>
<?php
echo"<h1> Cadastro</h1>";
echo"<hr><br>";

echo"<form action='inserir.php' method='POST'>";
echo "<hr>";
echo"NOME:<input type='text' name='nome'>";
echo "<hr>";
echo"<input type='hidden' name='data'>";
echo"<input type='hidden' name='hora'>";
echo"<input type='submit' value='Cadastrar'><br>";
echo"</form>";
echo"<hr><br>";
?>
</BODY>
</HTML>
