<!DOCTYPE html>
<html lang="pt-br">
<head><title></title><meta charset="utf-8"></head>
<body>
<table width=100% height=1000px border=1>
<tr><td colspan=2><?php include "cabecalho.php"; ?></td></tr>
<tr><td width=140 valign="top"><?php include "menu.php"; ?></td>
<td width=610> <table width=750 border=1 >
<tr><td valign="top"><?php include "home.php"; ?> </td> </tr></table> </td></tr>
<tr><td colspan=2><?php include "rodape.php";?></td></tr>
</table>
</body>
</HTML>